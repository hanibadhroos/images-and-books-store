<?php

declare(strict_types=1);

namespace Doctrine\DBAL;

/** @psalm-immutable */
class ConnectionException extends \Exception implements Exception
{
}
