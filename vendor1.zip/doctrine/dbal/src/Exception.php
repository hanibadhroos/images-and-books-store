<?php

declare(strict_types=1);

namespace Doctrine\DBAL;

use Throwable;

/** @psalm-immutable */
interface Exception extends Throwable
{
}
