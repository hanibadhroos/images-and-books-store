<div>
    <h1>New Report Submitted</h1>
    <p>{{ $inform }}</p>
    <a href="{{ route('informs') }}">Details</a>
</div>
