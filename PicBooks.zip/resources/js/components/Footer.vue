<template>
    <div class="parent pb-4">
        <div class="row p-2 m-0">
            <div class="col-md-4">
                <h3>About Us</h3>
                <p>We are a company which help designer for selling them photos and we help authers for selling them books, web designers can buy this photos into them design.</p>
            </div>
            <div class="col-md-4">
                <h3>Contact Us</h3>
                <a href="mailto:hani770894642@gmail.com" class="text-white p-1"><i class="text-white fa-solid fa-envelope"></i> Email</a>
                <br>
                <a href="https://wa.me/967770894642" class="text-white p-1"><i class="text-white fab fa-whatsapp"></i> WhatsApp</a>
            </div>
            <div class="col-md-4">
                <h3>Follow us</h3>
                <a href="https://facebook.com"><i class="fab fa-facebook text-white m-2"></i></a>
                <a href="https://instagram.com"><i class="fab fa-instagram text-white m-2"></i></a>
                <a href="https://twitter"><i class="fab fa-twitter text-white m-2"></i></a>
            </div>
        </div>
        <div class="text-center">
            <b><i class="fa fa-copyright" aria-hidden="true"></i> Copyright HANI SOFT</b>
        </div>
    </div>
</template>
<script>
export default{
    data(){
        return{

        }
    }
}
</script>

<style scoped>
    .parent{
        background-color: #1a1919;
        color: white;
        font-family:'Times New Roman', Times, serif;
    }

</style>
