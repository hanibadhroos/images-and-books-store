<div>
    <h1>New Report Submitted</h1>
    <p><?php echo e($inform); ?></p>
    <a href="<?php echo e(route('informs')); ?>">Details</a>
</div>
<?php /**PATH C:\xampp\htdocs\PicBooks\resources\views\emails\report_notification.blade.php ENDPATH**/ ?>